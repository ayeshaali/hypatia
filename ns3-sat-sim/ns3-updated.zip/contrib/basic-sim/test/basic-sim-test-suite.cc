/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include "apps/basic-sim-apps-test-suite.h"
#include "core/basic-sim-core-test-suite.h"
