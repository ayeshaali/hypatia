# Tools

This directory, which is not part of the ns-3 code, provides some useful tools to analyze the results of completed simulation run.

It encompasses the following sets of tools:

* `plotting` : Plotting helpers to plot ping, TCP flow, UDP burst and utilization statistics/attributes over time.
