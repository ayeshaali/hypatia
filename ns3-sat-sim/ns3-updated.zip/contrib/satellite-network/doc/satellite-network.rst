Satellite network module
----------------------------
